#pragma once
#include <iostream>
#include <sstream>
#include <fstream>
using namespace std;

struct Element{
  string abrev;
  string name;
  string weight;
  string number;
};

class Table{
  public:
    Element lookUpAb(string);
    Element lookUpANum(string);
};

Element Table::lookUpAb(string user){
  ifstream fin("elements.csv", ios::in);
  Element elem;
  if(isdigit(user[0])){
    elem.abrev = "10000";
  }
  else{
    while(elem.abrev != user){
      getline(fin, elem.number, ',');
      getline(fin, elem.name, ',');
      getline(fin, elem.abrev, ',');
      getline(fin, elem.weight, '\n');
    }
  }
  fin.close();
  return elem;
}

Element Table::lookUpANum(string user){
  ifstream fin("elements.csv", ios::in);
  Element elem;
  if(!isdigit(user[0])){
    elem.number = "a";
  }
  else{
    while(elem.abrev != user){
      getline(fin, elem.number, ',');
      getline(fin, elem.name, ',');
      getline(fin, elem.abrev, ',');
      getline(fin, elem.weight, '\n');
    }
  }
  fin.close();
  return elem;
}
